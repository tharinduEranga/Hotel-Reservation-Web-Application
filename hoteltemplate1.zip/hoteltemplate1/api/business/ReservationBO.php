<?php
/**
 * Created by IntelliJ IDEA.
 * User: Tharindu
 * Date: 11/24/2018
 * Time: 3:26 PM
 */
interface ReservationBO{
    function addReserve(ReservationDTO $reservationDTO):bool ;

}