DROP DATABASE IF EXISTS online_reservation;
CREATE DATABASE online_reservation;
USE online_reservation;
CREATE TABLE customer(
	cid INT(10) AUTO_INCREMENT,
	name VARCHAR(30),
	address VARCHAR(40),
	tel VARCHAR(20),
	nic VARCHAR(20),
	email VARCHAR(40),
	cardNo INT(20),
	password VARCHAR(30),
	CONSTRAINT PRIMARY KEY (cid)
);

CREATE TABLE roomType(
	rtid INT(10) AUTO_INCREMENT,
	description VARCHAR(30),
	price DOUBLE(10,2),
	CONSTRAINT PRIMARY KEY (rtid)
);

CREATE TABLE rooms(
	rid INT(10) AUTO_INCREMENT,
	rtid INT(10),
	CONSTRAINT PRIMARY KEY (rid),
	CONSTRAINT FOREIGN KEY (rtid) REFERENCES roomType(rtid)
	ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE reservations(
	rsid INT(10) AUTO_INCREMENT,
	no_of_rooms INT(10),
	date_in DATETIME,
	date_out DATETIME,
	total DECIMAL(10,2),
	cid INT(10),
	rtid INT(10),
	CONSTRAINT PRIMARY KEY (rsid),
	CONSTRAINT FOREIGN KEY (cid) REFERENCES customer(cid)
	ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT FOREIGN KEY (rtid) REFERENCES roomType(rtid)
	ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE payments(
	pid INT(10) AUTO_INCREMENT,
	pay_date DATE,
	amount DECIMAL(10,2),
	rsid INT(10),
	CONSTRAINT PRIMARY KEY(pid),
	CONSTRAINT FOREIGN KEY (rsid) REFERENCES reservations(rsid)
	ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE room_reserve (
	rrid INT(40)AUTO_INCREMENT,
	rid INT(10),
	rsid INT(10),
	CONSTRAINT PRIMARY KEY(rrid),
	CONSTRAINT FOREIGN KEY (rsid) REFERENCES reservations(rsid)
	ON UPDATE CASCADE ON DELETE CASCADE,
	CONSTRAINT FOREIGN KEY (rid) REFERENCES rooms(rid)
	ON UPDATE CASCADE ON DELETE CASCADE
);
SHOW TABLES;

CREATE TABLE admin(
	aid INT(10)AUTO_INCREMENT,
	name VARCHAR(30),
	password VARCHAR(30),
	telephone INT(10),
	CONSTRAINT PRIMARY KEY(aid)
);

INSERT INTO admin VALUES(0,"ijse","ijse",0838383283);


INSERT INTO customer VALUES (0,"Tharindu","Bentota",0774848482,"971929292v","tharindueranga3@gmail.com",882828838,"ijse");
INSERT INTO customer VALUES (0,"Supun","Alutgama",0774862682,"971982892v","geeksonu@gmail.com",838328838,"ijse");

INSERT INTO roomType VALUES(0,"Double Deluxe Room",4500);
INSERT INTO roomType VALUES(0,"Single Deluxe Room",3500);
INSERT INTO roomType VALUES(0,"Honeymoon Suit",7500);
INSERT INTO roomType VALUES(0,"Economy Double",2500);

INSERT INTO rooms VALUES (0,1);
INSERT INTO rooms VALUES (0,2);
INSERT INTO rooms VALUES (0,4);
INSERT INTO rooms VALUES (0,3);
INSERT INTO rooms VALUES (0,2);
INSERT INTO rooms VALUES (0,4);
INSERT INTO rooms VALUES (0,1);
INSERT INTO rooms VALUES (0,1);
INSERT INTO rooms VALUES (0,2);
INSERT INTO rooms VALUES (0,4);
INSERT INTO rooms VALUES (0,3);
INSERT INTO rooms VALUES (0,2);
INSERT INTO rooms VALUES (0,4);
INSERT INTO rooms VALUES (0,1);

INSERT INTO reservations VALUES(0,2,'2018-11-23 12:10',NOW(),5500,2,2);

INSERT INTO room_reserve VALUES(0,2,1);
INSERT INTO room_reserve VALUES(0,5,1);

INSERT INTO payments VALUES(0,CURRENT_DATE,5500,1);


/*checkout query
*/


SELECT rooms.rtid, COUNT(rooms.rid) FROM rooms WHERE rooms.rtid=2 AND rooms.rid NOT IN
(SELECT rid FROM room_reserve WHERE rsid NOT IN
(SELECT rsid FROM reservations WHERE (
(date_in<'2018-11-22 12:10:10' AND date_out<'2018-11-22 12:10:10')AND(date_in<'2018-11-25 12:10:10' AND date_out<'2018-11-25 12:10:10'))
OR 
(
(date_in>'2018-11-22 12:10:10' AND date_out>'2018-11-22 12:10:10')AND(date_in>'2018-11-25 12:10:10' AND date_out>'2018-11-25 12:10:10'))
)) GROUP BY rooms.rtid ;



SELECT rooms.rid FROM rooms WHERE rooms.rtid=1 AND rid NOT IN
(SELECT rid FROM room_reserve WHERE rsid NOT IN
(SELECT rsid FROM reservations WHERE (
(date_in<'2018-11-22 12:10:10' AND date_out<'2018-11-22 12:10:10')AND(date_in<'2018-11-25 12:10:10' AND date_out<'2018-11-25 12:10:10'))
OR 
(
(date_in>'2018-11-22 12:10:10' AND date_out>'2018-11-22 12:10:10')AND(date_in>'2018-11-25 12:10:10' AND date_out>'2018-11-25 12:10:10'))
)) GROUP BY rooms.rid ;


SELECT r.rsid, r.no_of_rooms, r.date_in, r.date_out, r.total , r.cid, r.rtid, rt.description FROM reservations r ,roomType rt WHERE r.rtid=rt.rtid AND r.cid=2 AND date_in >CURRENT_DATE;


SELECT r.rsid, r.no_of_rooms, r.date_in, r.date_out, r.total, c.name, c.tel, rm.rid, rm.rtid, rt.description FROM reservations r, rooms rm, customer c, room_reserve rr, roomType rt WHERE rt.rtid=r.rtid AND r.cid=c.cid AND r.rsid=rr.rsid AND rr.rid=rm.rid AND r.date_in>CURRENT_DATE GROUP BY r.rsid;




